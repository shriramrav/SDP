function [grid] = init() 
    for i = 1:4
        for j = 1:4
            grid(i, j) = i*i+j;
    
        end
    end
end


