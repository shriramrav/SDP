clc
clear

q = Queue();

q.enqueue('hello');

q.enqueue('bye');


% q.dequeue()