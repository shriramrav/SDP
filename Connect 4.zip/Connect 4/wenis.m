import java.util.LinkedList

q = LinkedList();

q.add('hello');

q.remove()