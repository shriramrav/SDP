classdef Queue
    properties
        queue
    end
    methods 
        function obj = Queue()
            obj.queue = [];
        end
        function obj = enqueue(obj, entry)
            fprintf('%i', length(obj.queue));
            
            
            obj.queue = [entry, obj.queue];
        end
        function [obj, entry] = dequeue(obj)
            entry = obj.queue(length(obj.queue));
            if (length(obj.queue) == 1) 
                obj.queue = [];
            else 
                obj.queue = obj.queue(1, length(obj.queue) - 1);
            end
        end
        function result = length(obj)
            result = length(obj.queue);
        end
    end
end