function [grid] = update(col, player, grid) 
    for i = 1:4
        if (grid(i, col) == 0)
            grid(i, col) = 
           
            

end