classdef Grid
    properties
        grid = [];
    end
    methods
%       Constructor
        function obj = Grid()
           for i = 1:4
               for j = 1:4
                   obj.grid(i, j) = 0;
               end
           end
        end
        
%       updates the grid for player placing disk
        function obj = update(col, player)
            for i = 1:4
                if (obj.grid(col, i) == 0)
                    obj.grid(col, i) = player;
                end
            end
        end
        
        function [obj, isWin] checkWin()
            
        
        end
    end
end