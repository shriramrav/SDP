%Clear command window and variables
clc
clear

%Dimensions of grid and amount of mines
%Easy: x = 8, y = 10, mines = 10
%Medium: x = 20, y = 14, mines = 40
%Hard: x = 24, y = 20, mines = 100
xAmount = 24;
yAmount = 20;
mineAmount = 90;
totalBlocks = xAmount*yAmount;
%Initialize simpleGameEngine object
gridGui = simpleGameEngine('Sprites.png', 16, 16, 5, [255,255,255]);
%Create both grids
[mineGrid, showGrid] = createGrid(xAmount,yAmount,mineAmount);
mineGrid
flagLoss = 0;
flagWin = 0;
firstClick = 1;
%Draw first the grid
drawGrid(gridGui,showGrid,mineGrid,flagLoss,flagWin);
%While Loop to test for win or loss
while(flagLoss == 0&& flagWin == 0)
%     x = input("Input x coordinate(Top Left is (1,1)): ");
%     y = input("Input y coordinate(Top Left is (1,1)): ");
    %User input
    [y,x,b] = getMouseInput(gridGui);
    %If it is a left click call the click function
    if(b == 1)
        [showGrid,flagLoss,mineGrid] = click(x,y,showGrid,mineGrid,firstClick);
        firstClick = 0;
    %If it is a right click flag the square
    elseif(b==3 && (showGrid(y,x)==11 || showGrid(y,x)==9))
        showGrid = rClick(x,y,showGrid);
    end
    %Check for winner
    [flagWin,minesLeft] = checkWin(xAmount,yAmount,showGrid,mineAmount);
    %Redraw grid
    drawGrid(gridGui,showGrid,mineGrid,flagLoss,flagWin);
    %Output if win or loss
    if(flagLoss == 1)
        f = msgbox("You Lost!!!");
    elseif(flagWin == 1)
        f = msgbox("You Won!!!");
    end
    
end

function drawGrid(gridGui,showGrid, mineGrid,flagLoss,flagWin)
    %If win or loss show where all mines are
    if(flagLoss==1 || flagWin==1)
        drawScene(gridGui,mineGrid)
    %Otherwise draw the show grid
    else
        drawScene(gridGui,showGrid);
    end
end

function [flagWin,minesLeft] = checkWin(y,x,showGrid,mineAmount)
    minesCaught = 0;
    flagWin = 0;
    %Check every square and count where mines arent clicked
    for i=1:x
        for j = 1:y
            if(showGrid(i,j)==9 || showGrid(i,j)==11)
                minesCaught = minesCaught+1;
            end    
        end
    end
    %If mines not clicked equals the amount of mines flag a win
    if(minesCaught == mineAmount)
        flagWin = 1;
    end
    minesLeft = minesCaught-mineAmount;
end

function [mineGrid, showGrid] = createGrid(y,x,mines)
    %Initialize mine grid where all mines and numbered squares will be seen
    mineGrid = zeros(x,y);
    %Initialize show grid which will be what the user sees
    showGrid = zeros(x,y)+11;%11 corresponds with a blank square on sprite sheet so it is easily drawn
    numMines = 0;
    %Makes sure the correct amount of mines are placed
    while numMines<mines
       %Random coordinates of mines
        xCor = randi(x);
       yCor = randi(y);
       %Makes sure a mine is not already there before placing
       if mineGrid(xCor,yCor)~= 10
          mineGrid(xCor,yCor) = 10;%10 corresponds to a bomb on the sprite sheet
          numMines = numMines+1;
       end
    end
    %Loops through every square on grid and if it doesn't have a mine, the
    %calcNums function is called to count mines around that square
    for i=1:x
        for j = 1:y
            if(mineGrid(i,j)~=10)
                mineGrid(i,j) = calcNums(i,j,mineGrid);
                if(mineGrid(i,j)==0)
                    mineGrid(i,j) = 12;%Changed number to 12 because the 0 corresponds to slot 12 on sprite sheet
                end
            end    
        end
    end
end

function showGrid = rClick(y,x,showGrid)
    %If the square that is right clicked is already flagged changes to blank square(number corresponds with sprite sheet)    
    if showGrid(x,y) == 9
        showGrid(x,y) = 11;
    %Flags a square
    elseif showGrid(x,y) == 11
        showGrid(x,y) = 9;
    end
    
end

function [showGrid,flagLoss,mineGrid] = click(y,x,showGrid,mineGrid, firstClick)
    flagLoss = 0;
    %If the first click is a mine then it moves that mine to the top left
    %corner or the first available slot along the columns
    if firstClick == 1
        if mineGrid(x,y)==10
            flag = 0;
            for i = 1:height(mineGrid)
                for j = 1:width(mineGrid)
                    if(flag == 0 && mineGrid(j,i) ~= 10)
                        mineGrid(j,i) = 10;
                        mineGrid(x,y) = 0;
                        flag = 1;
                    end
                end
            end
            for j=1:width(mineGrid)
                for i = 1:height(mineGrid)
                    if(mineGrid(i,j)~=10)
                        mineGrid(i,j) = calcNums(i,j,mineGrid);
                        if(mineGrid(i,j)==0)
                            mineGrid(i,j) = 12;
                        end
                    end    
                end
            end
        end
    end
    %If a mine is clicked then a loss is flagged and the showgrid is
    %replaced by the mineGrid so all bombs are shown
    if (mineGrid(x,y)==10)
        showGrid(x,y) = mineGrid(x,y);
        flagLoss =1;
    %If a zero is clicked then the zeroClicked function is called
    elseif(mineGrid(x,y)==12)
        showGrid = zeroClicked(x,y,showGrid,mineGrid);
    %Otherwise that square is replaced by the corresponding value on the
    %mine grid
    else
        showGrid(x,y) = mineGrid(x,y);
    end
end

function showGrid = zeroClicked(x,y,showGrid,mineGrid)
    countX = width(mineGrid);
    countY = height(mineGrid);
    %Makes sure that a square that is not in the grid is not clicked
    if(y<1||y>countX||x<1||x>countY)
        return;
    elseif(mineGrid(x,y)==12 && showGrid(x,y) ~= mineGrid(x,y))
        %If a zero is clicked all the squares around the zero(we know there are no mines around it) are
        %recursively called with the zeroClicked function
        showGrid(x,y) = mineGrid(x,y);
        showGrid = zeroClicked(x,y-1,showGrid,mineGrid);
        showGrid = zeroClicked(x+1,y-1,showGrid,mineGrid);
        showGrid = zeroClicked(x+1,y,showGrid,mineGrid);
        showGrid = zeroClicked(x+1,y+1,showGrid,mineGrid);
        showGrid = zeroClicked(x,y+1,showGrid,mineGrid);
        showGrid = zeroClicked(x-1,y+1,showGrid,mineGrid);
        showGrid = zeroClicked(x-1,y,showGrid,mineGrid);
        showGrid = zeroClicked(x-1,y-1,showGrid,mineGrid);
        
        %If the square is on the edge of the grid, only the available
        %squares are called with the click function. Otherwise all 8
        %squares are clicked because we know there are no mines around a 0
        if(x==1)
            if(y==1)
                [showGrid,~,~] = click(y+1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x+1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y,x+1,showGrid,mineGrid,0);
            elseif(y == countX)
                [showGrid,~,~] = click(y-1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y-1,x+1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y,x+1,showGrid,mineGrid,0);
            else
                [showGrid,~,~] = click(y-1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y-1,x+1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y,x+1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x+1,showGrid,mineGrid,0);
            end
        elseif(x==countY)
            if(y==1)
                [showGrid,~,~] = click(y+1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x-1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y,x-1,showGrid,mineGrid,0);
            elseif(y == countX)
                [showGrid,~,~] = click(y-1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y-1,x-1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y,x-1,showGrid,mineGrid,0);
            else
                [showGrid,~,~] = click(y-1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y-1,x-1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y,x-1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x-1,showGrid,mineGrid,0);
            end
        else
            if(y==1)
                [showGrid,~,~] = click(y,x-1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x-1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x+1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y,x+1,showGrid,mineGrid,0);
            elseif(y==countX)
                [showGrid,~,~] = click(y,x-1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y-1,x-1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y-1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y-1,x+1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y,x+1,showGrid,mineGrid,0);
            else
                [showGrid,~,~] = click(y,x-1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x-1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y+1,x+1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y,x+1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y-1,x+1,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y-1,x,showGrid,mineGrid,0);
                [showGrid,~,~] = click(y-1,x-1,showGrid,mineGrid,0);
            end    
         end
    else
        %Break case
        return;
    end
end

function numMinesAround = calcNums(y,x,mineGrid)
    numMinesAround = 0;
    countX = width(mineGrid);
    countY = height(mineGrid);
    %If the square is on the edge of the grid, only the available
    %squares are passed into the countMine function to count and added 
    % together to count how many mines are around the current square in the
    % grid. Otherwise all 8 squares are passed into the countMine function
    if(y==1)
        if(x==1)
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
        elseif(x == countX)
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
        else
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y+1,mineGrid);
        end
    elseif(y==countY)
        if(x==1)
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
        elseif(x == countX)
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
        else
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y-1,mineGrid);
        end
    else
        if(x==1)
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
        elseif(x==countX)
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
        else
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y-1,mineGrid);
        end    
    end
end

function numMines = countMine(y,x,mineGrid)
    numMines = 0;
    %if the square selected has a mine then a one is returned
    if(mineGrid(x,y)==10)
        numMines = numMines+1;
    end
end

