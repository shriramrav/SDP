clc
clear

xAmount = 8;
yAmount = 10;
mineAmount = 10;
totalBlocks = xAmount*yAmount;
gridGui = simpleGameEngine('Sprites.png', 16, 16, 5, [255,255,255]);
[mineGrid, showGrid] = createGrid(xAmount,yAmount,mineAmount)
flagLoss = 0;
flagWin = 0;
drawGrid(gridGui,showGrid,mineGrid,flagLoss,flagWin);
while(flagLoss == 0&& flagWin == 0)
%     x = input("Input x coordinate(Top Left is (1,1)): ");
%     y = input("Input y coordinate(Top Left is (1,1)): ");
    [y,x,b] = getMouseInput(gridGui);
    if(b == 1)
        [showGrid,flagLoss] = click(x,y,showGrid,mineGrid);
    elseif(b==3 && (showGrid(y,x)==11 || showGrid(y,x)==9))
        showGrid = rClick(x,y,showGrid);
    end
    [flagWin,minesLeft] = checkWin(xAmount,yAmount,showGrid,mineAmount);
    minesLeft
    showGrid
    mineGrid
    drawGrid(gridGui,showGrid,mineGrid,flagLoss,flagWin,xAmount,yAmount);
    if(flagLoss == 1)
        f = msgbox("You Lost!!!");
    elseif(flagWin == 1)
        f = msgbox("You Won!!!");
    end
    
end

function drawGrid(gridGui,showGrid, mineGrid,flagLoss,flagWin)
    if(flagLoss==1 || flagWin==1)
        drawScene(gridGui,mineGrid)
    else
        drawScene(gridGui,showGrid);
    end
end

function [flagWin,minesLeft] = checkWin(y,x,showGrid,mineAmount)
    minesCaught = 0;
    flagWin = 0;
    for i=1:x
        for j = 1:y
            if(showGrid(i,j)==9 || showGrid(i,j)==11)
                minesCaught = minesCaught+1;
            end    
        end
    end
    if(minesCaught == mineAmount)
        flagWin = 1;
    end
    minesLeft = minesCaught-mineAmount;
end

function [mineGrid, showGrid] = createGrid(y,x,mines)
    mineGrid = zeros(x,y);
    showGrid = zeros(x,y)+11;
    numMines = 0;
    while numMines<mines
       xCor = randi(x);
       yCor = randi(y);
       if mineGrid(xCor,yCor)~= 10
          mineGrid(xCor,yCor) = 10;
          numMines = numMines+1;
       end
    end
    for i=1:x
        for j = 1:y
            if(mineGrid(i,j)~=10)
                mineGrid(i,j) = calcNums(i,j,mineGrid);
                if(mineGrid(i,j)==0)
                    mineGrid(i,j) = 12;
                end
            end    
        end
    end
end

function showGrid = rClick(y,x,showGrid)
    if showGrid(x,y) == 9
        showGrid(x,y) = 11;
    elseif showGrid(x,y) == 11
        showGrid(x,y) = 9;
    end
    
end

function [showGrid,flagLoss] = click(y,x,showGrid,mineGrid)
    flagLoss = 0;
    
    if (mineGrid(x,y)==10)
        showGrid(x,y) = mineGrid(x,y);
        flagLoss =1;
    elseif(mineGrid(x,y)==12)
        showGrid = zeroClicked(x,y,showGrid,mineGrid);
    else
        showGrid(x,y) = mineGrid(x,y);
    end
end

function showGrid = zeroClicked(x,y,showGrid,mineGrid)
    countX = width(mineGrid);
    countY = height(mineGrid);
    if(y<1||y>countX||x<1||x>countY)
        return;
    elseif(mineGrid(x,y)==12 && showGrid(x,y) ~= mineGrid(x,y))
        showGrid(x,y) = mineGrid(x,y);
        showGrid = zeroClicked(x,y-1,showGrid,mineGrid);
        showGrid = zeroClicked(x+1,y-1,showGrid,mineGrid);
        showGrid = zeroClicked(x+1,y,showGrid,mineGrid);
        showGrid = zeroClicked(x+1,y+1,showGrid,mineGrid);
        showGrid = zeroClicked(x,y+1,showGrid,mineGrid);
        showGrid = zeroClicked(x-1,y+1,showGrid,mineGrid);
        showGrid = zeroClicked(x-1,y,showGrid,mineGrid);
        showGrid = zeroClicked(x-1,y-1,showGrid,mineGrid);
        
        if(x==1)
            if(y==1)
                [showGrid,~] = click(y+1,x,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x+1,showGrid,mineGrid);
                [showGrid,~] = click(y,x+1,showGrid,mineGrid);
            elseif(y == countX)
                [showGrid,~] = click(y-1,x,showGrid,mineGrid);
                [showGrid,~] = click(y-1,x+1,showGrid,mineGrid);
                [showGrid,~] = click(y,x+1,showGrid,mineGrid);
            else
                [showGrid,~] = click(y-1,x,showGrid,mineGrid);
                [showGrid,~] = click(y-1,x+1,showGrid,mineGrid);
                [showGrid,~] = click(y,x+1,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x+1,showGrid,mineGrid);
            end
        elseif(x==countY)
            if(y==1)
                [showGrid,~] = click(y+1,x,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x-1,showGrid,mineGrid);
                [showGrid,~] = click(y,x-1,showGrid,mineGrid);
            elseif(y == countX)
                [showGrid,~] = click(y-1,x,showGrid,mineGrid);
                [showGrid,~] = click(y-1,x-1,showGrid,mineGrid);
                [showGrid,~] = click(y,x-1,showGrid,mineGrid);
            else
                [showGrid,~] = click(y-1,x,showGrid,mineGrid);
                [showGrid,~] = click(y-1,x-1,showGrid,mineGrid);
                [showGrid,~] = click(y,x-1,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x-1,showGrid,mineGrid);
            end
        else
            if(y==1)
                [showGrid,~] = click(y,x-1,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x-1,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x+1,showGrid,mineGrid);
                [showGrid,~] = click(y,x+1,showGrid,mineGrid);
            elseif(y==countX)
                [showGrid,~] = click(y,x-1,showGrid,mineGrid);
                [showGrid,~] = click(y-1,x-1,showGrid,mineGrid);
                [showGrid,~] = click(y-1,x,showGrid,mineGrid);
                [showGrid,~] = click(y-1,x+1,showGrid,mineGrid);
                [showGrid,~] = click(y,x+1,showGrid,mineGrid);
            else
                [showGrid,~] = click(y,x-1,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x-1,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x,showGrid,mineGrid);
                [showGrid,~] = click(y+1,x+1,showGrid,mineGrid);
                [showGrid,~] = click(y,x+1,showGrid,mineGrid);
                [showGrid,~] = click(y-1,x+1,showGrid,mineGrid);
                [showGrid,~] = click(y-1,x,showGrid,mineGrid);
                [showGrid,~] = click(y-1,x-1,showGrid,mineGrid);
            end    
         end
    else
        return;
    end
end

function numMinesAround = calcNums(y,x,mineGrid)
    numMinesAround = 0;
    countX = width(mineGrid);
    countY = height(mineGrid);
    
    if(y==1)
        if(x==1)
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
        elseif(x == countX)
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
        else
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y+1,mineGrid);
        end
    elseif(y==countY)
        if(x==1)
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
        elseif(x == countX)
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
        else
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y-1,mineGrid);
        end
    else
        if(x==1)
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
        elseif(x==countX)
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
        else
            numMinesAround = numMinesAround + countMine(x,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y-1,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x+1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y+1,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y,mineGrid);
            numMinesAround = numMinesAround + countMine(x-1,y-1,mineGrid);
        end    
    end
end

function numMines = countMine(y,x,mineGrid)
    numMines = 0;
    if(mineGrid(x,y)==10)
        numMines = numMines+1;
    end
end

